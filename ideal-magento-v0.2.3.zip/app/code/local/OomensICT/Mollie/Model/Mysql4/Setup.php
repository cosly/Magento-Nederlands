<?php
/**
 * @category   OomensICT
 * @package    OomensICT_Mollie
 * @copyright  Copyright (c) 2009 Oomens ICT
 */

/**
 * Setup Model
 *
 * @category   OomensICT
 * @package    OomensICT_Mollie
 */
class OomensICT_Mollie_Model_Mysql4_Setup extends Mage_Sales_Model_Mysql4_Setup
{

}
